# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['nnreplayer',
 'nnreplayer.form_nn',
 'nnreplayer.mip',
 'nnreplayer.repair',
 'nnreplayer.utils']

package_data = \
{'': ['*']}

install_requires = \
['Pyomo>=6.2,<7.0',
 'Shapely>=1.8.0,<2.0.0',
 'gurobipy>=9.5.0,<10.0.0',
 'matplotlib>=3.5.1,<4.0.0',
 'numpy>=1.22.1,<2.0.0',
 'scipy>=1.7.3,<2.0.0',
 'sklearn>=0.0,<0.1',
 'tensorflow>=2.8.0,<3.0.0']

setup_kwargs = {
    'name': 'nnreplayer',
    'version': '0.0.2',
    'description': 'NN Layer Repair',
    'long_description': None,
    'author': 'Tanmay Bhaskar Khandait',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<3.10',
}


setup(**setup_kwargs)
